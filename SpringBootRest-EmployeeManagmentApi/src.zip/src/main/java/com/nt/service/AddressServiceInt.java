package com.nt.service;

import com.nt.entity.Address;
import com.nt.entity.Employee;

public interface AddressServiceInt {

	public void saveAddress(Address address);

}
