package com.nt.service;

import com.nt.entity.Department;

public interface DepartmentServiceInt {

	public void saveDepartment(Department department);
}
