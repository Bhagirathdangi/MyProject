package com.nt.service;

import com.nt.entity.Employee;

public interface EmployeeServiceInt {

	public void saveEmployee(Employee employee);
}
